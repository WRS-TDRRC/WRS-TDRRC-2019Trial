import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS2", "AGXSimulator", "DoubleArmV7A")
