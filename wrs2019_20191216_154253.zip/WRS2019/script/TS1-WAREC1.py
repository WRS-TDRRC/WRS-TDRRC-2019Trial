import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS1", [ "AGXSimulator", "AISTSimulator" ], "WAREC1")
