import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS1", "AGXSimulator", "AizuSpiderSA",
    enableVisionSimulation = True, remoteType = "ROS")
