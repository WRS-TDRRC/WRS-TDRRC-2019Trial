import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS1", "AGXSimulator", "DoubleArmV7A")
