import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS4", "AGXSimulator", "DoubleArmV7A")
