import WRSUtil
WRSUtil.loadProject(
    "MultiSceneViews", "TS3", "AGXSimulator", "DoubleArmV7A")
